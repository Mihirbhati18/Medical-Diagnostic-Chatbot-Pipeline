# Medical Chatbot with OCR Lab Report Integration 🏥🤖

An intelligent, full-stack Medical Chatbot built with Python, PyTorch, and Scikit-Learn that allows users to type symptoms and upload physical lab reports. By combining Natural Language Processing (NLP) with Computer Vision (OpenCV + Tesseract OCR), the bot extracts quantitative clinical markers, maps them to symptoms, and runs a comprehensive matrix prediction to guess the underlying disease.

## Features ✨

- **Text-based Symptom Chat:** Users can type symptoms natively, and the PyTorch NLP model handles intent extraction via bag-of-words and Cross Entropy Loss arrays.
- **OCR Lab Report Scanning:** Users can upload blood-work lab reports. The OpenCV engine denoises and processes the image, while `pytesseract` extracts text. 
- **Quantitative Extraction Regex:** A robust Regex engine accurately pulls values for 12 key markers (e.g., Glucose, RBC, Platelets) regardless of abbreviation formats.
- **Disease Vector Prediction:** All user text-symptoms and lab-parsed symptoms are combined and checked against a Random Forest Classifier trained on a **4,920 record** dataset matrix (`dataset.csv`), predicting standard pathologies.
- **Severity Warning System:** Scans combined symptoms against `Symptom-severity.csv`. If the maximum or mean bounds exceed the internal danger-index threshold, an automated hospital warning is spawned.
- **Beautiful UI:** Modern Glass-morphism design, color-coded lab-evaluations, and real-time JS animations.

---

## Architecture & Pipeline ⚙️

1. **Vision Pre-processing:** `cv2.fastNlMeansDenoising` & `cv2.adaptiveThreshold`
2. **Text Generation:** Tesseract Optical Character Recognition (OCR) 
3. **Data Parsing:** Regex Alias Matching
4. **Logic Evaluation:** String State evaluation against Medical Boundary references
5. **Machine Learning Extrapolation:** ML Vector Symptom Generation -> Random Forest Predictor -> Result

---

## Requirements

Python 3.5 or newer.

**System Requirements:**
- [Tesseract OCR engine](https://github.com/tesseract-ocr/tesseract) installed on your machine.
  - *Windows*: Ensure installed in `C:\Program Files\Tesseract-OCR\tesseract.exe` (or x86) so the `lab_analyzer.py` engine can locate it.

**Python Dependencies:**
- `Flask`
- `torch` (PyTorch)
- `nltk`
- `numpy`
- `scikit-learn`
- `pandas`
- `opencv-python` (cv2)
- `pytesseract`
- `Pillow`

---

## Installation & Setup 🛠️

We recommend using a virtual environment.

### Linux / Mac:
```bash
python3 -m venv venv
source venv/bin/activate
pip install flask torch nltk numpy scikit-learn pandas opencv-python pytesseract Pillow
```

### Windows:
```cmd
py -3 -m venv venv
venv\Scripts\activate
pip install flask torch nltk numpy pandas scikit-learn opencv-python pytesseract Pillow
```

### Initializing NLTK Tokenization
In order for text-tokenization to process, the `punkt` and `wordnet` packages must be downloaded locally via Python:
```python
import nltk
nltk.download('punkt')
```

---

## Run The Server 🚀

To start MedicalChatbot Backend Server, run:
```bash
python app.py
```
*(Alternatively, you can also run `python -m flask run`)*

The server will launch in development mode, access the web client at:
`http://127.0.0.1:5000/`

Press `CTRL+C` to quit.
